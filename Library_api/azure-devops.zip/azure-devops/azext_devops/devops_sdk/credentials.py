
from msrest.authentication import (
    BasicAuthentication,
    BasicTokenAuthentication,
    OAuthTokenAuthentication)
